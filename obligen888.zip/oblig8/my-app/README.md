# Oppgave8
