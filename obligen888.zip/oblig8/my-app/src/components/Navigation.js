import { NavLink } from 'react-router-dom'

export default function Navigation() {
  return (
    <header>
      <nav>
        <a href="/" id="logo">
          Hjem
        </a>
        <ul>
          <li>
            <NavLink to="/">Hjem</NavLink>
          </li>
          <li>
            <NavLink to="movies">Filmer</NavLink>
          </li>
          <li>
            <NavLink to="actors">Skuespillere</NavLink>
          </li>
        </ul>
      </nav>
    </header>
  )
}