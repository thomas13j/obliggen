import Movie from "../components/Movie"

export default function MovieE() {
    return (
        <>
        <Movie />
        </>
    )
  }