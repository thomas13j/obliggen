import Actors from "../components/Actors";

export default function ActorsS() {
    return (
        <>
        <Actors />
        </>
    )
}