import Movies from "../components/Movies"

export default function MoviesS() {
    return (
        <>
        <Movies />
        </>
    )
}