import Actor from "../components/Actor";

export default function ActorR() {
    return (
        <>
        <Actor />
        </>
    )
}