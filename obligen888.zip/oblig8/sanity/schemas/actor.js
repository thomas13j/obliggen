import {UserIcon} from '@sanity/icons'

const actor = {
  name: 'actor',
  title: 'Skuespiller',
  type: 'document',
  icon: UserIcon,
  fields: [
    {
      name: 'name',
      title: 'Fult navn',
      type: 'string',
      description: 'Skriv navn og etternavn',
      validation: (Rule) => Rule.required(),
    },
    {
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      description: 'Den unike url',
      options: {
        source: 'name',
        maxLength: 100,
      },
    },
    {
      name: 'image',
      title: 'Bilde',
      type: 'image',
      options: {
        hotspot: true,
      },
    },
  ],
  preview: {
    select: {title: 'name', media: 'image'},
  },
}

export default actor