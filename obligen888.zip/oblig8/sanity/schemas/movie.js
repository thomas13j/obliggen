import {MdLocalMovies as icon} from 'react-icons/md'

const movie = {
  name: 'movie',
  title: 'Film',
  type: 'document',
  icon,
  fields: [
    {
      name: 'title',
      title: 'Title',
      type: 'string',
      description: 'Navnet på filmen',
    },
    {
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      description: 'Den unike url',
      validation: (Rule) => Rule.required(),
      options: {
        source: 'title',
        maxLength: 100,
      },
    },
    {
      name: 'summary',
      title: 'Film beskrivelse',
      type: 'text',
    },
    {
      name: 'poster',
      title: 'Film bilde',
      type: 'image',
      options: {
        hotspot: true,
      },
    },
    {
      title: 'Skuespiller',
      name: 'actor',
      type: 'reference',
      to: [{ type: 'actor' }],
    },
  ],
  preview: {
    select: {
      title: 'title',
      media: 'poster',
      actor: 'actor.name',
    },
    prepare(selection) {
      const { title, actor } = selection
      return {
        title,
        date: selection.date,
        subtitle: `Actor: ${actor}`,
        media: selection.media,
      }
    },
  },
}

export default movie
